from bubble_sort import __main__

if __name__ == "__main__":
    __main__.main()

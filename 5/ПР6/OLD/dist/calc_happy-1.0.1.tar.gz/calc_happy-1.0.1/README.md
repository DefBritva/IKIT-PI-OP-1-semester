<p style="font-size: 19px">This is simply package for calculating happy numbers.
<a href="https://en.wikipedia.org/wiki/Happy_number">Happy Numbers</a></p>

<p style="font-size: 17px">Usage:</p>

Run tests:
    <b>python -m calc_happy -t</b>

Run doctest:
    <b>python -m calc_happy -b</b>

Run program:
    <b>python -m calc_happy [upper_limit]</b>
